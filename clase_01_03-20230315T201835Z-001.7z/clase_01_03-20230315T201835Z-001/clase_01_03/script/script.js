let nombre, correo, mensaje
let formulario = document.getElementById('form')
formulario.addEventListener('submit', (e)=>{
    e.preventDefault
    leerdatos()
})

function leerdatos () {
    nombre = document-getElementById('nombre').value
    correo = document-getElementById('correo').value
    mensaje = document-getElementById('mensaje').value
}

function ValidadData(nombre,correo,mensaje) {
    if(nombre.length==0 || correo.length==0 || mensaje.length==0){

    Swal.fire({
title: 'Error',
Text: 'do you want to cotinue',
icon: 'error',
confirmButtonText: 'Cool',
iconColor: 'purple'

    })


     }
}
